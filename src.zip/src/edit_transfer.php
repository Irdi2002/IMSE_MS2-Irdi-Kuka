<?php
// Database credentials
$host = 'MySQLDockerContainer'; // MySQL container name
$db = 'IMSE_MS2';               // Updated database name
$user = 'root';                 // MySQL username
$pass = 'IMSEMS2';              // MySQL root password

try {
    // Create a new PDO connection
    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch the transfer header
    $transferID = $_GET['TransferID'] ?? null;
    $message = $_GET['message'] ?? null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Save changes to the TransferHeader
        $originWarehouse = $_POST['origin_warehouse'];
        $destinationWarehouse = $_POST['destination_warehouse'];
        $transferDate = $_POST['transfer_date'];

        $updateHeaderStmt = $pdo->prepare(
            "UPDATE TransferHeader 
            SET OriginWarehouseID = :origin, DestinationWarehouseID = :destination, TransferDate = :date 
            WHERE TransferID = :transferID"
        );
        $updateHeaderStmt->execute([
            ':origin' => $originWarehouse,
            ':destination' => $destinationWarehouse,
            ':date' => $transferDate,
            ':transferID' => $transferID
        ]);

        // Check if transfer lines are provided
        if (!empty($_POST['product_id']) && !empty($_POST['quantity'])) {
            $productIDs = $_POST['product_id'];
            $quantities = $_POST['quantity'];

            // Delete existing lines for this TransferID
            $deleteLinesStmt = $pdo->prepare("DELETE FROM TransferLines WHERE TransferID = :transferID");
            $deleteLinesStmt->execute([':transferID' => $transferID]);

            // Insert updated lines
            $insertLineStmt = $pdo->prepare(
                "INSERT INTO TransferLines (TransferID, ProductID, Quantity) VALUES (:transferID, :productID, :quantity)"
            );

            for ($i = 0; $i < count($productIDs); $i++) {
                $insertLineStmt->execute([
                    ':transferID' => $transferID,
                    ':productID' => $productIDs[$i],
                    ':quantity' => $quantities[$i]
                ]);
            }
        }

        // Redirect back to the same page with a success message
        header("Location: edit_transfer.php?TransferID=$transferID&message=Changes saved successfully!");
        exit;
    }

    if (!$transferID) {
        echo "<p>Error: TransferID not provided.</p>";
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM TransferHeader WHERE TransferID = :TransferID");
    $stmt->execute([':TransferID' => $transferID]);
    $transfer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transfer) {
        echo "<p>Error: Transfer not found.</p>";
        exit;
    }

    // Fetch the transfer lines with product names
    $lineStmt = $pdo->prepare(
        "SELECT tl.*, p.Name AS ProductName 
        FROM TransferLines tl 
        JOIN Product p ON tl.ProductID = p.ProductID 
        WHERE tl.TransferID = :TransferID"
    );
    $lineStmt->execute([':TransferID' => $transferID]);
    $lines = $lineStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch all warehouses for dropdowns
    $warehouseStmt = $pdo->query("SELECT WarehouseID FROM Warehouse");
    $warehouses = $warehouseStmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Transfer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f0f8ff; /* AliceBlue */
        }
        h1 {
            text-align: center;
            color: #0078D7; /* Vibrant Blue */
        }
        form {
            background-color: #fff;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
            color: #333;
        }
        select,
        input[type="text"],
        input[type="date"],
        input[type="number"],
        input[type="submit"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #0078D7; /* Vibrant Blue */
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #005BB5; /* Darker Blue */
        }
        .success-message {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .back-arrow {
            margin-bottom: 20px;
            text-align: left;
            margin-left: calc(50% - 400px); /* Align with form start */
        }
        .back-arrow a {
            text-decoration: none;
            font-size: 16px;
            color: white;
            background-color: #0078D7; /* Vibrant Blue */
            padding: 10px 15px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease-in-out;
            display: inline-flex;
            align-items: center;
        }
        .back-arrow a:hover {
            background-color: #005BB5; /* Darker Blue */
        }
        .back-arrow a svg {
            margin-right: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        table th {
            background-color: #0078D7;
            color: white;
        }
        .delete-row {
            background-color: #ff4d4d; /* Red */
            color: white;
            border: none;
            cursor: pointer;
            padding: 5px 10px;
            border-radius: 4px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease-in-out;
            font-size: 12px;
        }
        .delete-row:hover {
            background-color: #cc0000; /* Darker Red */
        }
    </style>
    <script>
        function deleteRow(button) {
            const row = button.parentElement.parentElement;
            row.remove();
        }
    </script>
</head>
<body>
    <h1>Edit Transfer</h1>
    <div class="back-arrow">
        <a href="view_transfers.php">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18px" height="18px">
                <path fill="currentColor" d="M21 11H6.414l5.293-5.293-1.414-1.414L3.586 12l6.707 6.707 1.414-1.414L6.414 13H21v-2z"/>
            </svg>
            Transfer List
        </a>
    </div>

    <?php if ($message): ?>
        <div class="success-message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label for="origin_warehouse">Origin Warehouse:</label>
        <select id="origin_warehouse" name="origin_warehouse" required>
            <?php
                foreach ($warehouses as $warehouse) {
                    $selected = $warehouse['WarehouseID'] === $transfer['OriginWarehouseID'] ? 'selected' : '';
                    echo "<option value=\"" . htmlspecialchars($warehouse['WarehouseID']) . "\" $selected>" 
                         . htmlspecialchars($warehouse['WarehouseID']) 
                         . "</option>";
                }
            ?>
        </select>

        <label for="destination_warehouse">Destination Warehouse:</label>
        <select id="destination_warehouse" name="destination_warehouse" required>
            <?php
                foreach ($warehouses as $warehouse) {
                    $selected = $warehouse['WarehouseID'] === $transfer['DestinationWarehouseID'] ? 'selected' : '';
                    echo "<option value=\"" . htmlspecialchars($warehouse['WarehouseID']) . "\" $selected>" 
                         . htmlspecialchars($warehouse['WarehouseID']) 
                         . "</option>";
                }
            ?>
        </select>

        <label for="transfer_date">Transfer Date:</label>
        <input type="date" id="transfer_date" name="transfer_date" value="<?= htmlspecialchars($transfer['TransferDate']) ?>" required>

        <h2>Transfer Lines</h2>
        <table>
            <thead>
                <tr>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lines as $line): ?>
                    <tr>
                        <td><input type="text" name="product_id[]" value="<?= htmlspecialchars($line['ProductID']) ?>" readonly></td>
                        <td><?= htmlspecialchars($line['ProductName']) ?></td>
                        <td><input type="number" name="quantity[]" value="<?= htmlspecialchars($line['Quantity']) ?>" min="1" required></td>
                        <td><button type="button" class="delete-row" onclick="deleteRow(this)">Delete</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <input type="submit" value="Save Changes">
    </form>
</body>
</html>
