<?php
// Database credentials
$host = 'MySQLDockerContainer';
$db = 'IMSE_MS2';
$user = 'root';
$pass = 'IMSEMS2';

try {
    // Create a new PDO connection
    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch warehouse information with products and aisle
    $stmt = $pdo->query("
        SELECT 
            w.WarehouseName,
            wi.Aisle,
            w.Address AS WarehouseAddress,
            p.ProductID,
            p.Name AS ProductName,
            p.Weight,
            p.UnitOfMeasure,
            wi.Quantity AS ProductQuantity
        FROM 
            Warehouse w
        LEFT JOIN 
            WarehouseInventory wi ON w.WarehouseID = wi.WarehouseID
        LEFT JOIN 
            Product p ON wi.ProductID = p.ProductID
        ORDER BY 
            w.WarehouseName, wi.Aisle, p.Name
    ");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warehouse and Products List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f0f8ff; /* AliceBlue */
        }
        h1 {
            text-align: center;
            color: #0078D7; /* Vibrant Blue */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #0078D7; /* Vibrant Blue */
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
            transform: scale(1.01);
            transition: all 0.2s ease-in-out;
        }
        td {
            color: #555; /* Subtle Gray */
        }
    </style>
</head>
<body>
    <h1>Warehouse and Products List</h1>
    <table>
        <thead>
            <tr>
                <th>Warehouse Nr</th>
                <th>Aisle</th>
                <th>Address</th>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Weight</th>
                <th>Unit of Measure</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($data)): ?>
                <?php foreach ($data as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['WarehouseName']) ?></td>
                        <td><?= htmlspecialchars($row['Aisle'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($row['WarehouseAddress']) ?></td>
                        <td><?= htmlspecialchars($row['ProductID'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($row['ProductName'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($row['Weight'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($row['UnitOfMeasure'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($row['ProductQuantity'] ?? 'N/A') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8">No data available</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
